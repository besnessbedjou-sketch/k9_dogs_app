package com.k9dogs.app;

import android.content.*;import android.database.Cursor;import android.database.sqlite.*;import java.util.*;

public class DatabaseHelper extends SQLiteOpenHelper {
 public DatabaseHelper(Context c){super(c,"k9dogs.db",null,1);}
 public void onCreate(SQLiteDatabase db){
  db.execSQL("CREATE TABLE dogs(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,breed TEXT,sex TEXT,main_spec TEXT,extra_specs TEXT,birth TEXT,trainer TEXT,service TEXT,photo TEXT)");
  db.execSQL("CREATE TABLE vaccines(id INTEGER PRIMARY KEY AUTOINCREMENT,dog_id INTEGER,name TEXT,date TEXT,FOREIGN KEY(dog_id) REFERENCES dogs(id) ON DELETE CASCADE)");
 }
 public void onUpgrade(SQLiteDatabase db,int o,int n){}
 public long addDog(ContentValues v){return getWritableDatabase().insert("dogs",null,v);}
 public void updateDog(long id,ContentValues v){getWritableDatabase().update("dogs",v,"id=?",new String[]{""+id});}
 public void deleteDog(long id){getWritableDatabase().delete("vaccines","dog_id=?",new String[]{""+id});getWritableDatabase().delete("dogs","id=?",new String[]{""+id});}
 public Cursor dogs(){return getReadableDatabase().query("dogs",null,null,null,null,null,"id DESC");}
 public Cursor dog(long id){return getReadableDatabase().query("dogs",null,"id=?",new String[]{""+id},null,null,null);}
 public long addVaccine(long dogId,String name,String date){ContentValues v=new ContentValues();v.put("dog_id",dogId);v.put("name",name);v.put("date",date);return getWritableDatabase().insert("vaccines",null,v);}
 public Cursor vaccines(long dogId){return getReadableDatabase().query("vaccines",null,"dog_id=?",new String[]{""+dogId},null,null,"date ASC");}
 public void deleteVaccine(long id){getWritableDatabase().delete("vaccines","id=?",new String[]{""+id});}
}
