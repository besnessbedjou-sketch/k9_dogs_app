package com.k9dogs.app;
import android.app.*;import android.content.*;import android.os.*;
public class ReminderReceiver extends BroadcastReceiver{
 public void onReceive(Context c,Intent i){String dog=i.getStringExtra("dog");String vac=i.getStringExtra("vac");
  String ch="vaccines"; NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"تذكيرات التطعيمات",NotificationManager.IMPORTANCE_HIGH));
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("موعد تطعيم K9").setContentText(dog+" — "+vac).setAutoCancel(true);
  nm.notify((int)(System.currentTimeMillis()%100000),b.build());
 }
}
